import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.amazon.com/exec/obidos/tg/browse/-/1055398')

WebUI.closeBrowser()

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.amazon.in/')

WebUI.setText(findTestObject('Object Repository/Amazon_Wishlist_OR/Page_Amazon.in/input_field-keywords'), 'UFXJFN')

WebUI.click(findTestObject('Object Repository/Amazon_Wishlist_OR/Page_Amazon.in/button_Continue shopping'))

WebUI.setText(findTestObject('Object Repository/Amazon_Wishlist_OR/Page_Online Shopping site in India Shop Onl_10c5f3/input_field-keywords'), 
    'laptop')

WebUI.click(findTestObject('Object Repository/Amazon_Wishlist_OR/Page_Online Shopping site in India Shop Onl_10c5f3/div_laptop'))

WebUI.click(findTestObject('Object Repository/Amazon_Wishlist_OR/Page_Amazon.in  laptop/span_Acer Travelmate Business Laptop Intel _f01e48'))

WebUI.switchToWindowTitle('Acer Travelmate Business Laptop Intel Core i5-1135G7 Processor (8GB DDR4/ 512GB SSD/Intel Iris Xe Graphics/Windows 11 Home/MS Office) TMP214-53 with 35.56 cm (14.0") Full HD Display : Amazon.in: Electronics')

WebUI.click(findTestObject('Object Repository/Amazon_Wishlist_OR/Page_Acer Travelmate Business Laptop Intel _d453bd/input_a-button-input'))

WebUI.closeBrowser()

